<?php
namespace Ari\Models;

use Ari\Utils\Options as Options;

class Model_Options extends Options {
    public $class_prefix  = '';
}
