<?php
namespace Ari\Views;

use Ari\Utils\Options as Options;

class View_Options extends Options {
    public $domain = '';
}
