<?php
namespace Ari\Controls\Tabs;

use Ari\Utils\Options as Options;

class Tabs_Main_Options extends Options {
    public $class = '';
}
