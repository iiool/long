<?php
namespace Ari\Controllers;

class Ajax_Options extends Controller_Options {
    public $nopriv = false;

    public $json_encode_options = 0;
}
